---
name: exit-timing-calendar
description: Build a probabilistic liquidity calendar for a private-markets portfolio (VC, PE, real estate, credit) over a 2-10 year horizon. Use when someone wants to map out when investments might exit, get marked up, or throw off cash, and is stuck because exit dates are unknowable. Turns each position into an exit-year distribution plus an outcome distribution, then reports expected cash, median cash and a liquidity-risk read per year rather than a calendar of guessed dates. Triggers - "exit timing", "liquidity calendar", "when will my deals exit", "map out my exits", "distribution waterfall", "when do I get my money back".
---

# Exit Timing Calendar

## The problem this solves

Someone has ten or twenty private positions and wants to know what the next five to
seven years of liquidity look like. They sit down to build a calendar, and immediately
hit the wall: **you cannot know when a private company exits.** Not approximately, not
within a year. The founder does not know. The sponsor does not know.

So the calendar stalls, and the usual fallbacks both fail:

- **Guess a date per deal.** You now have a calendar of numbers that are wrong in
  unknown directions, and it looks authoritative. Worse than nothing, because people
  plan against it.
- **Use the worst-case date for everything.** Reasonable instinct, and it fails for a
  different reason: worst-casing twenty positions independently produces a calendar
  that says "no liquidity until 2033," which is itself a near-impossible outcome. Tail
  cases do not all happen at once. Stacking conservatism is not conservative, it is
  just a different wrong answer.

**The fix is to stop trying to produce a date.** A date is the wrong output type for
a thing that is genuinely uncertain. Produce a distribution, and read the calendar as
a risk map instead of a schedule.

## The core idea

Give each position **two distributions instead of two guesses**. One over what it
returns, one over when. Then play the whole book a few thousand times and read what
each year looks like across all of those runs, rather than picking one run and calling
it a forecast.

## Method

### Step 1 — Classify every position by CASH TYPE, and never sum across types

This is the step people skip, and it is the one that makes the rest honest. Three
buckets:

| Type | What it is | Date | Amount | Goes on the calendar as |
|---|---|---|---|---|
| **Contractual** | Preferred return, credit coupon, rent, scheduled amortization | Knowable | Knowable | A real number |
| **Structural** | Fund term plus extensions, lockup expiry, redemption window | A bounded window from the LPA | Unknown | A window, no amount |
| **Speculative** | VC exit, secondary, markup, opportunistic sale | Unknowable | Unknowable | A distribution only |

**Never let contractual and speculative cash add into one figure.** A calendar showing
"2029: $340,000" that mixes a contractual $40k preferred return with a speculative
$300k exit is not a forecast, it is a trap. Report them on separate rows that never
total. The contractual row is what you can plan on. The speculative row is what you
hope for.

### Step 2 — For speculative positions, capture three things you already have

No new research required. All three come off the deal doc or the original memo.

0. **Commitment and uncalled balance.** Exit proceeds are `commitment x multiple`, not
   `funded-to-date x multiple`: by the time an exit lands the whole commitment has been
   called, so funded-to-date understates the position. That is only honest if the
   uncalled balance also appears as capital calls on the outflow side. Both numbers,
   doing different jobs.
1. **Stage at entry** (pre-seed / seed / Series A / Series B+, or for non-VC: the
   sponsor's stated hold period). Stage drives both the multiple band and the hold.
2. **Exit window**: `earliest`, `likely`, `latest`. Build a range around whatever
   single date the tracker holds rather than treating that date as a point: a year or
   two earlier, a couple of years later. Precision is not the goal. Replacing a date
   nobody can know with a range that can be defended is the goal.
3. **Conviction**: a simple 1-5 or low/medium/high. This shifts the outcome
   probabilities, not the multiple.

### Step 3 — Outcome distribution, not a point multiple

A single expected MOIC is the second trap. Venture returns follow a power law, so the
average outcome and the typical outcome are different numbers, and the average is
carried entirely by a branch that probably will not happen to any given deal.

The default shape, from the standard ten-deal venture math:

| Branch | Probability | Multiple |
|---|---|---|
| Total loss | 30% | 0x |
| Return of capital / acqui-hire | 30% | ~1x |
| Modest, equity-like | 30% | ~1.3-2x over the hold |
| The winner | 10% | the stage's target band |

Stage target bands (earlier means riskier, so the required multiple rises):

| Stage | Target multiple |
|---|---|
| Pre-seed ($3-10M) | 30-40x |
| Seed ($8-20M) | 7-15x |
| Series A ($15-40M) | 3-10x |
| Series B+ ($40M+) | 2-4x |

**Do not count the preferred returns twice.** A multiple is total distributions over
invested capital, so any preferred return paid along the way is already inside it.
Showing a preferred-return column *and* exiting at the full multiple counts that cash
twice; on a real book it inflated the typical outcome by about 14%. For any position
paying a preferred return, exit on the residual:
`(commitment x MOIC - preferred paid over the hold) / commitment`. Venture pays no
preferred return, so venture multiples are untouched.

Adjust per deal with conviction, and **haircut the sponsor's number**. A sponsor's
projected MOIC is a marketing figure produced by the party being paid. It belongs in
the "winner" branch, not as the expected value of the whole position.

For non-VC sleeves the same structure applies with a much tighter spread. Stabilized
real estate or private credit might run 5% loss / 25% below plan / 55% at plan / 15%
above. The method does not change, only the numbers.

### Step 3a — A fund is not one big deal. Ask how many investments it holds

The branches above describe a **single** deal, and their first branch is a 30% chance of
returning nothing. That is right for an SPV into one company. Applied to a fund holding
twenty or more companies it is not conservative, it is impossible: a 0.00x result would
need every company in the fund to fail at once. Published fund data contains no 0.00x at
all — the bottom quartile fails to return capital, the long-run median lands near 1.5x.

Ask for a deal count on every position. If the user cannot say, assume 1 and tell them
so, because assuming diversification nobody declared is inventing it.

| Deals held | Treatment |
|---|---|
| 1 | Step 3 unchanged |
| 2–19 | Step 3 for the outcome, but stage the timing (Step 4a) |
| 20 or more | The fund table below, and stage the timing |

The fund table, as a fraction of whatever multiple the sponsor is targeting:

| Probability | Fraction of target |
|---|---|
| 10% | 0.18 |
| 15% | 0.25 |
| 25% | 0.38 |
| 25% | 0.56 |
| 15% | 0.76 |
| 10% | the full target |

On a typical target this reproduces the published fund benchmarks: p10 0.70x, p25 1.00x,
median 1.50x, p75 2.20x, p90 3.00x. Note where it leaves the sponsor's own number —
around the 95th percentile, which is where a target belongs.

**Do not derive this by averaging twenty single-deal draws.** Averaging says a twenty-deal
fund is nearly risk-free, which is false. Deals inside one fund share a vintage and
managers differ, so pooling collapses the left tail without narrowing the right one. The
table is fitted to what funds actually did, not to what averaging predicts.

### Step 4 — Timing is right-skewed. Exits slip late, never early

This matters more than people expect. A symmetric "plus or minus a year" is wrong,
because there is no mechanism that makes an exit happen early and several that make it
happen late. Weight accordingly:

| Window | Weight |
|---|---|
| `earliest` | 20% |
| `likely` | 50% |
| `latest` | 25% |
| `later than latest` | 5% |

That last row is not padding. Funds extend. It is the single most common way a
liquidity plan breaks, and leaving it out is how a calendar quietly becomes optimistic.

The opposite error is just as easy: stacking the skew on top of a date that was already
a late estimate. That pushes every exit several years too far out and makes the calendar
look emptier and later than it is. Build the range around the date, not after it.

### Step 4a — A fund does not exit on a date either. It sells down over years

Any position holding more than one deal pays out across a window rather than in a single
year. On a calendar this is the larger of the two fund errors, because the calendar is the
whole point. Offsets are from the drawn exit year:

| | −3 | −2 | −1 | 0 | +1 | +2 |
|---|---|---|---|---|---|---|
| Venture fund | 10% | 15% | 20% | 25% | 18% | 12% |
| Income fund | — | 15% | 25% | 35% | 25% | — |

The weights sum to 1, so staging **moves** money between years and never creates or
destroys any. Check that: lifetime totals must be identical with and without it. If part
of the window falls outside the years being reported, renormalise the weights over the
years that remain rather than dropping that slice — otherwise cash silently disappears.
That exact bug cost 0.12% of a real book's mean before the check caught it.

A single-company position does not get this. If the company is bought, the whole company
is bought on one date.

### Step 5 — Simulate, then report three things per year

Run a few thousand trials. Each trial draws an exit year and an outcome branch for
every speculative position, and sums the cash landing in each year.

Report per year:

1. **Contractual cash.** A real number. Plan on this.
2. **Median speculative cash (p50).** What a typical future actually delivers.
   **This is usually far lower than the average, and often zero.**
3. **The range (p10 to p90).** How wide the year is.

And report the two headline numbers side by side, because the gap between them is the
whole lesson:

- **Expected (mean) total over the horizon** — what you get if you own the entire
  distribution many times over.
- **Median total over the horizon** — what a single run of your actual life looks like.

The gap is largest on a single position and in any single year, where the median is
often zero while the mean is not. On a diversified book the horizon totals converge,
which is diversification working rather than a bug, so do not assert a fixed ratio.
**You cannot plan on the mean.** You own one draw, not the distribution.

### Step 5b — Percentile discipline

Two different kinds of percentile live in this output and they must never be mixed.

**Per-year** percentiles rank each year separately, so the run in the middle in one
year is a different run from the middle one in another. **These columns cannot be
added.** Stacking a per-year 90th percentile overstated one real book's lifetime
figure by 69%. Print a warning beside any such column.

**Cumulative** percentiles add each run up first, then rank once. Every figure is a
real total a real future actually reached, so this one **is** safe to read down, and
it is the planning view. Its last row must tie exactly to the lifetime totals, which
is the reader's check that both panels are one model. Subtracting one cumulative row
from another is a rough guide rather than arithmetic, because a different future can
sit in the middle in each year.

### Step 5c — Profit means against the full commitment

Profit is total received less **every dollar committed**, not less the uncalled
balance. Netting only the remaining calls ignores what is already funded and makes a
thin result look healthy: on one book it showed $437,194 where the real profit was
$28,194.

### Step 6 — What to read off it

The output is not a prediction. It answers three questions well:

- **Which years are thin?** Consecutive years where median speculative cash is near
  zero and contractual cash does not cover commitments. Those are the years to fund in
  advance.
- **Where do capital calls collide with dry spells?** Overlay the call schedule. A
  call landing in a thin year is the failure mode that forces a bad sale elsewhere.
- **How much of the plan rides on one position?** If removing the single largest
  position moves the mean by more than about a third, the calendar is a forecast of one
  deal wearing a portfolio costume.

## Output format

Produce, in this order:

0. **Four panels, in order**: year-by-year (what happens IN each year, not addable),
   cumulative (how much has arrived BY each year, addable, the planning view),
   lifetime totals (received, profit, multiple), then a glossary.
1. **Inputs table** — every position with stage, commitment, uncalled balance, number of underlying deals, exit window, branch
   probabilities, and a `source` column recording where each number came from
   (`sponsor`, `LPA`, `my estimate`). Provenance is not decoration; a number from a
   sponsor deck and a number from a signed LPA deserve different confidence.
2. **Year-by-year table** — contractual cash, median speculative, p10, p90, and a
   thin-year flag.
3. **Two totals** — mean and median over the horizon, side by side, with the ratio.
4. **Three to five sentences of plain reading** — where the thin years are, what
   drives them, and what single change would most improve the picture.
5. **What would change this** — the two or three inputs the answer is most sensitive
   to, so the reader knows what to revisit.

## Non-negotiables

- **Never present a speculative figure as expected cash.** Label it, separate it, and
  keep it out of any total that contractual cash appears in.
- **Never add a per-year percentile column down**, and warn the reader not to.
- **Never exit at the full multiple** on a position that also pays a preferred return.
- **Never apply the single-deal branches to a fund of twenty or more.** Their 30% chance
  of zero describes an outcome such a fund cannot produce. State the deal count used for
  every position.
- **Never let staging change a lifetime total.** If it does, weights are falling off the
  end of the window and cash is being deleted.
- **Never call it profit** unless it is measured against the full commitment.
- **Never report a mean without its median beside it.** In a power law the mean alone
  is misleading and the error is always in the optimistic direction.
- **Record provenance on every number.** Sponsor projection, LPA term, and personal
  estimate are three different epistemic objects.
- **State the horizon's limits.** Past about seven years the distribution is so wide
  that the honest answer is "wide," and saying so is more useful than a precise-looking
  number.
- **No single-point exit dates anywhere in the output.** If a date is genuinely
  contractual, it belongs in the contractual bucket.

## Cost of ignoring this

You build a calendar of guessed dates, plan around it, and then two things happen at
once: the exits slip (because they always do) and a capital call lands in the gap. Now
you are selling something liquid at a bad moment to cover something illiquid, which is
the specific failure that turns a good portfolio into a bad year. Being illiquid rather
than being unprofitable is what forces bad decisions. The calendar exists to find that
collision before it happens, and a calendar of confident wrong dates hides it instead.
